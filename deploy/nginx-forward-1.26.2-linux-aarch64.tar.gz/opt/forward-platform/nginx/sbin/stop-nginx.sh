#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/.." && pwd)"
if [ -f "${BASE}/logs/nginx.pid" ]; then
  "${BASE}/sbin/nginx" -p "${BASE}" -e "${BASE}/logs/error.log" -c "${BASE}/conf/nginx.conf" -s quit || true
  echo "nginx 已停止"
else
  echo "未找到 PID 文件"
fi
